# Program State

## Snapshot

- date: 2026-03-18
- program: AI + manufacturing PMF discovery
- stage: initialization
- horizon: 6 months
- human collaborator: Anthony
- agent collaborator: 小智
- decision owner: human
- operating owner: agent + human

## Mission

Find one or more narrow, evidence-backed AI+manufacturing product opportunities with credible pull signals, not just technical feasibility.

## Non-goals

- Do not start by designing a broad platform.
- Do not treat model capability demos as product validation.
- Do not promote opportunities without source evidence.

## Working thesis

- The best early opportunities are likely to sit inside high-frequency, high-friction workflows.
- The strongest first wedges are likely to have existing digital exhaust such as documents, images, logs, or operator records.
- Human review is acceptable if it materially reduces cycle time, rework, or missed defects.
- Buyer, user, and approver may be different roles and must be tracked separately.

## Phase goals

### Phase 1: Weeks 1-2

- finalize scoring rubric v1
- build opportunity pool v1
- cluster opportunities by workflow and buyer
- define PMF signal thresholds for this lab

### Phase 2: Weeks 3-8

- run small validation experiments on the top opportunities
- identify repeat pain and willingness-to-engage signals
- retire weak ideas quickly and record why

### Phase 3: Weeks 9-24

- deepen evidence on the top 1-3 wedges
- look for repeat pull, urgency, and budget path
- convert validated patterns into reusable knowledge

## Current priorities

1. Build the first opportunity pool.
2. Define a scoring rubric that rewards pain, frequency, evidence, and feasible deployment.
3. Design the first low-cost validation experiments.

## Current PMF signal summary

- No PMF signal yet.
- The lab is still at opportunity discovery setup stage.
- Near-term signal to seek: repeated pain from similar manufacturers plus willingness to continue the conversation, share data, or review a narrow prototype.

## Next deliverables

- opportunity pool v1
- scoring rubric v1
- first 10 opportunity hypotheses
- first 3 validation experiments
