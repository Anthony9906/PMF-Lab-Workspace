# Operating Model

## Purpose

This is the procedural layer for repeated opportunity discovery work.

## What belongs here

- Opportunity intake rules
- Scoring rubric
- Experiment design rules
- Review cadence
- Naming conventions
- Promotion and retirement rules

## What does not belong here

- Live project facts
- Raw source notes
- Unverified insights
- Results that still need review

## Default loop

1. Create or update an opportunity card.
2. Add source notes and evidence.
3. Draft a hypothesis.
4. Design the smallest test that can fail.
5. Run the test.
6. Record outcome and decision.
7. Promote stable patterns to Canonical knowledge.

