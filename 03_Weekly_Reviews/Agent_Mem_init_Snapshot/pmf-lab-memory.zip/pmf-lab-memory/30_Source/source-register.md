# Source Register

Track the evidence used for opportunity discovery.

## Source types

- interview notes
- process docs
- screenshots
- SOPs
- tickets
- meeting notes
- system exports
- observation logs

## Minimum metadata

- source id
- date
- owner
- origin
- linked opportunity ids
- confidence

## Registered sources

- source id: SRC-2026-03-18-001
- date: 2026-03-18
- owner: Anthony + 小智
- origin: kickoff session and agent first-principles synthesis
- linked opportunity ids: OPP-001, OPP-002, OPP-003, OPP-004, OPP-005, OPP-006, OPP-007, OPP-008, OPP-009, OPP-010
- confidence: low

Note: this source is a hypothesis seed, not external market validation.
