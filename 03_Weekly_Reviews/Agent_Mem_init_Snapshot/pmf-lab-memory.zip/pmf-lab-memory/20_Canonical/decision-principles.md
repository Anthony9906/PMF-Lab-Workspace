# Decision Principles

## Principles

- Prefer workflows with repeat volume and measurable pain.
- Prefer agent work where sources already exist.
- Prefer narrow slices that can be tested quickly.
- Do not promote a pattern without evidence.
- Retain why something failed, not just that it failed.

